import './style.css'
import javascriptLogo from './javascript.svg'
import viteLogo from '/vite.svg'
import { setupCounter } from './counter.js'
import './swiper';
import './style.css';
import './weather';
import { API_KEY } from './secret.js';